using System.Windows.Forms;

namespace BitcoinFinder
{
    public class StandaloneForm : Form
    {
        public StandaloneForm()
        {
            this.Text = "Bitcoin Finder - Standalone";
            this.Width = 800;
            this.Height = 600;
        }
    }
} 